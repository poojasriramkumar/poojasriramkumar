sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("PoojaPortalProject.controller.FinalPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf PoojaPortalProject.view.FinalPage
		 * 
		 */
		 onInit: function(){
		 	
		 },
		onAfterRendering  : function() {
			var service = "/sap/opu/odata/sap/ZPM_ODATA_PS_SRV_01/";

			var oModel = new sap.ui.model.odata.ODataModel(service, true);

			var uri = "?$filter=Plant eq '0001'";
			var no;
			oModel.read("/ZPM_ET_WOL_POOJASet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

					no = oData.results;
				}
			});
			var ooModel = new sap.ui.model.json.JSONModel(no);
			this.getView().setModel(ooModel, "wo_list");
			//NOTIFICATION

			var service1 = "/sap/opu/odata/sap/ZPM_ODATA_PS_SRV_01";

			var oModel1 = new sap.ui.model.odata.ODataModel(service1, true);

			var uri1 = "?$filter=Plantgroup eq '010' and Planplant eq '0001' and Date eq datetime'2022-04-04T00:00:00'";
			var no1;
			oModel1.read("/ZPM_ET_NL_POOJASet" + uri1, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

					no1 = oData.results;
				}
			});
			var ooModel1 = new sap.ui.model.json.JSONModel(no1);
			this.getView().setModel(ooModel1, "no_list");
			window.console.log(ooModel1);

		},

		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("PoojaPortalProject.view.Fragments.nodetails", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		displaydetails_no: function(oEvent) {
			this._getDialog().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat = new sap.ui.model.json.JSONModel(objcurrent);
			this._oDialog.setModel(mat);
		},
		onClose: function() {
			this._getDialog().close();
		},

		_getDialog1: function() {
			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("PoojaPortalProject.view.Fragments.wodetails", this);
				this.getView().addDependent(this._oDialog1);
			}
			return this._oDialog1;
		},
		displaydetails_wo: function(oEvent) {
			this._getDialog1().open();
			var objcurrent1 = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat = new sap.ui.model.json.JSONModel(objcurrent1);
			this._oDialog1.setModel(mat);
		},
		onClose1: function() {
			this._getDialog1().close();
		}

	});

});