sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("PoojaPortalProject.controller.ShopFloor_LoginPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf PoojaPortalProject.view.ShopFloor_LoginPage
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf PoojaPortalProject.view.ShopFloor_LoginPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf PoojaPortalProject.view.ShopFloor_LoginPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf PoojaPortalProject.view.ShopFloor_LoginPage
		 */
		//	onExit: function() {
		//
		//	}
		onNext: function() {
			var Inp_username = this.getView().byId("id_username").getValue();
			var Inp_password = this.getView().byId("id_password").getValue();
			if (Inp_username === "" && Inp_password === "") {
				MessageBox.alert("Username and Password is Mandatory");
			}
			else {
			var surl = '/sap/opu/odata/sap/ZPM_ODATA_PS_SRV_01/';
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			var uri = "Userid='"+Inp_username+"',Password='"+Inp_password+"'";
			window.console.log(uri);
			// var name;
			// var passwrd;
			var status;
			oModel.read("/ZPM_ET_LOGIN_POOJA1Set(" + uri + ")", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, OResponse) {
					window.console.log("Success", oData);
					window.console.log("Response", OResponse);
					Inp_username = parseInt(oData["Userid"]);
				 Inp_password	=  parseInt(oData["Password"]);


					status = oData["Status"];
					 
				}
			});
			}

			// var users = {
			// 	"user": name,
			// 	"password": passwrd
			// };

			// var sampleModel = new sap.ui.model.json.JSONModel(users);
			// sap.ui.getCore().setModel(sampleModel, "baseinfo");

			if (status === "TRUE") {
				var orouter = sap.ui.core.UIComponent.getRouterFor(this);
				orouter.navTo("ShopFloor_DashboardPage");
			} else {
				window.console.log("Server Error or User not found");
			}
		
		},
			onCancel: function() {
			this.getView().byId("id_username").setValue("");
			this.getView().byId("id_password").setValue("");
		}


	});

});